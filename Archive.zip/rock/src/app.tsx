// @flow
import React, {Fragment} from 'react';
import PropTypes from 'prop-types';
import {
  // BrowserRouter as Router,
  HashRouter as Router,
  Link,
  NavLink
} from "react-router-dom";
import {connect} from 'react-redux';

import {get, isEmpty} from 'lodash';

import './app.sass';
import routesFactory from './routesFactory';

import {fetchAccount} from './shared/actions';
import {hashHistory, history} from './shared/helper';

export interface AppProps {
  fetchAccount: any,
  currentAccount: any,
  prePath?: any
}

class App extends React.Component<AppProps, object> {
  static propTypes: AppProps;

  componentDidMount() {
    this.props.fetchAccount();
  }

  componentDidUpdate(prevProps: any) {
    // TODO: 
    const {currentAccount: {role: prevRole}} = prevProps;
    const {currentAccount: {role}, prePath} = this.props;

    if (!isEmpty(role) && prevRole !== role && hashHistory.location.pathname !== prePath) {
      history.push(prePath);
    }
  }

  render() {
    const {currentAccount: {role}} = this.props;
    return (
      <Fragment>
        <header>header</header>
        <Router basename="/rock/">
          <ul>
            <li>
              <Link to="/example">example</Link>
              <NavLink to="/example" activeClassName="at">rock example</NavLink>
              <a href="/ir/typescriptStarter" rel="link">rock to ir</a>
              <NavLink to="/typescriptStarter" activeClassName="at">rock typescriptStarter</NavLink>
              <NavLink to="/ir/lazy" activeClassName="at">ir lazy</NavLink>
              <NavLink to="/lazy" activeClassName="at">rock lazy</NavLink>
              <a href="/hugo/typescriptStarter" rel="link" target="_blank">rock to hugo</a>
            </li>
          </ul>
          {routesFactory(role)}
        </Router>
        <footer>footer</footer>
      </Fragment>
    );
  }
}

App.propTypes = {
  fetchAccount: PropTypes.func.isRequired,
  currentAccount: PropTypes.object.isRequired,
  prePath: PropTypes.string
};

const mapStateToProps = (state: any) => {
  return {
    currentAccount: get(state, 'account'),
    prePath: get(state, 'error.prePath')
  };
};

const mapDispatchToProps = (dispatch: any) => ({
  fetchAccount: () => dispatch(fetchAccount())
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App);
