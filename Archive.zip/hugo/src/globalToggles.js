
export default {
  loggedIn: true,
}
