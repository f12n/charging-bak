
export interface testState {
  testName: string;
  enthusiasmLevel: number;
}

