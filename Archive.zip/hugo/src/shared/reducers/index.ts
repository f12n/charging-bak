export * from './accountReducer';
export * from './globalReducer';

// import {combineReducers} from 'redux';
// import accountReducer from './accountReducer';
// import globalReducer from './globalReducer';

// export default combineReducers({
//   accountReducer,
//   globalReducer
// });
