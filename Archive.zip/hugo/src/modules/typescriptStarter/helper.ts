
export function getExclamationMarks(numChars: number) {
  return Array(numChars + 1).join('!');
}
