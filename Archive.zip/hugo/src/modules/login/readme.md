This is the component which only load api data, have no state tree.
